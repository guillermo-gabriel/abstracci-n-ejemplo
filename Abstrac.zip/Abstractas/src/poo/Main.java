package poo;

public class Main {

	public static void main(String[] args) {

		Persona[] lasPersonas = new Persona[2];

		lasPersonas[0]= new Empleado("pedro",100,2003,03,12);
		lasPersonas[1]= new Alumno("jose","Informatica");


		for(Persona p: lasPersonas) {
			System.out.println(p.dameNombre()+" "+ p.dameDescripcion());
		}

	}
}